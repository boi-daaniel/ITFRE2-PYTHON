from db_connection import create_connection

# PIN Management Function
def change_pin(account_number):
    conn = create_connection()
    if conn is None:
        print("Unable to connect to the database.")
        return


    old_pin = input("Enter your current PIN: ")
    new_pin = input("Set a new 6-digit PIN: ")

    if len(new_pin) != 6 or not new_pin.isdigit():
        print("PIN must be 6 digits.")
        return

    try:
        with conn.cursor() as cursor:
            cursor.execute("SELECT * FROM users WHERE account_number=%s AND pin=%s", (account_number, old_pin))
            user = cursor.fetchone()

            if user:
                cursor.execute("UPDATE users SET pin=%s WHERE account_number=%s", (new_pin, account_number))
                conn.commit()
                print("PIN changed successfully!")
            else:
                print("Incorrect current PIN.")
    finally:
        conn.close()
