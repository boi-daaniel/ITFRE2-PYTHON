from db_connection import create_connection
from decimal import Decimal
from datetime import date

# Deposit Function
def deposit(account_number):
    conn = create_connection()
    if conn is None:
        print("Unable to connect to the database.")
        return

    try:
        print("--Cash Deposit--")
        amount = Decimal(input("Enter amount: "))

        with conn.cursor() as cursor:
            cursor.execute("SELECT total_deposited_today, last_transaction_date FROM users WHERE account_number=%s", (account_number,))
            user = cursor.fetchone()

            total_deposited_today, last_transaction_date = user

            if last_transaction_date != date.today():
                total_deposited_today = Decimal(0)

            if total_deposited_today + amount > Decimal(10000):
                print("Exceeded daily deposit limit.")
            else:
                cursor.execute("UPDATE users SET balance=balance+%s, total_deposited_today=total_deposited_today+%s, last_transaction_date=%s WHERE account_number=%s",
                               (amount, amount, date.today(), account_number))
                conn.commit()
                print(f"Deposit successful! Amount Deposited: {amount:.2f}.")
    finally:
        conn.close()
