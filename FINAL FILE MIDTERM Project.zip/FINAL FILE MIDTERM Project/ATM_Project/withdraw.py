from db_connection import create_connection
from decimal import Decimal
from datetime import date

# Withdraw cash function
def withdraw(account_number):
    conn = create_connection()
    if conn is None:
        print("Unable to connect to the database.")
        return

    try:
        print("--Cash Withdraw--")
        amount = Decimal(input("Enter amount: "))

        with conn.cursor() as cursor:
            cursor.execute("SELECT balance, total_withdrawn_today, last_transaction_date FROM users where account_number = %s",
                           (account_number,))
            user = cursor.fetchone()

            balance, total_withdrawn_today, last_transaction_date = user

            if last_transaction_date != date.today():
                total_withdrawn_today = Decimal(0)

            if amount > balance:
                print("Insufficient funds.")
            elif total_withdrawn_today + amount > Decimal(5000):
                print("Exceeded daily withdrawal limit.")
            else:
                cursor.execute("UPDATE users SET balance=balance-%s, total_withdrawn_today=total_withdrawn_today+%s, last_transaction_date=%s WHERE account_number=%s",
                               (amount, amount, date.today(), account_number))
                conn.commit()
                print(f"Withdraw successful! Amount withdrew: {amount:.2f}. New Balance: {balance:.2f}")
    finally:
        conn.close()
