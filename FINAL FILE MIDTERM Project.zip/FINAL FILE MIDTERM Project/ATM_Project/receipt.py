from db_connection import create_connection

# Print receipt function
def print_receipt(account_number):
    conn = create_connection()
    if conn is None:
        print("Unable to connect to the database.")
        return

    try:
        with conn.cursor() as cursor:
            cursor.execute("SELECT full_name, account_number, balance FROM users WHERE account_number=%s", (account_number,))
            user = cursor.fetchone()

            if user:
                print(f"\t--ATM Receipt--\nAccount Name: \t{user[0]}\nAccount Number: \t{user[1]}\nCurrent Balance: \t${user[2]:.2f}")
            else:
                print("Account not found.")
    finally:
        conn.close()
