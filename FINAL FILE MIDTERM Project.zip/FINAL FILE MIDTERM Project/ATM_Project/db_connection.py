import mysql.connector
from mysql.connector import Error

# DB Connection
def create_connection():
    try:
        conn = mysql.connector.connect(
            host="localhost",
            user="user",
            password="1234",
            database="atm"
        )
        return conn
    except Error as e:
        print(f"Error: '{e}' occurred.")
        return None

