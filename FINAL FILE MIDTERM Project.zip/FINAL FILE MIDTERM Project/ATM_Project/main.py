from balance import check_balance
from deposit import deposit
from login import login
from pin_management import change_pin
from receipt import print_receipt
from registration import register_user
from withdraw import withdraw


def main():
    while True:
        print("\n --ATM MENU--")
        print("1. Register")
        print("2. Login")
        print("0. Exit ")

        choice = input("Choose option: ")

        if choice == "1":
            register_user()
        elif choice == "2":
            account_number = login()
            if account_number:
                while True:
                    print("\n\t--User Menu--")
                    print("1. Check Balance")
                    print("2. Change Pin")
                    print("3. Withdraw ")
                    print("4. Deposit ")
                    print("5. Print Receipt ")
                    print("6. Log Out ")

                    user_choice = input("\tSelect Option: ")
                    if user_choice == "1":
                        check_balance(account_number)
                    elif user_choice == "2":
                        change_pin(account_number)
                    elif user_choice == "3":
                        withdraw(account_number)
                    elif user_choice == "4":
                        deposit(account_number)
                    elif user_choice == "5":
                        print_receipt(account_number)
                    elif user_choice == "6":
                        print("Signing out...")
                        break
                    else:
                        print("Invalid option. Please select a valid option.")
        elif choice == "0":
            print("Exiting ATM")
            break
        else:
            print("Invalid option. Please select a valid option.")

if __name__ == "__main__":
    main()
