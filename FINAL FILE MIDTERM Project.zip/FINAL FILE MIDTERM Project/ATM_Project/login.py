from db_connection import create_connection

# Login Function
def login():
    conn = create_connection()
    if conn is None:
        print("Unable to connect to the database.")
        return None

    account_number = input("Enter your account number: ")
    pin = input("Enter your PIN: ")

    try:
        with conn.cursor() as cursor:
            cursor.execute("SELECT * FROM users WHERE account_number=%s AND pin=%s", (account_number, pin))
            user = cursor.fetchone()

            if user:
                print("Login successful!")
                return account_number
            else:
                print("Invalid credentials")
                return None
    finally:
        conn.close()
