from db_connection import create_connection
from datetime import date
import random

# Registration Function
def register_user():
    conn = create_connection()
    if conn is None:
        print("Unable to connect to the database.")
        return

    full_name = input("Enter your full name: ")
    pin = input("Set a 6-digit PIN: ")

    if len(pin) != 6 or not pin.isdigit():
        print("PIN must be 6 digits.")
        return

    account_number = acc_number_generator()

    try:
        with conn.cursor() as cursor:
            # Check if account already exists
            cursor.execute("SELECT * FROM users WHERE account_number=%s", (account_number,))
            if cursor.fetchone():
                print("Account already exists.")
                return

            cursor.execute("INSERT INTO users (full_name, account_number, pin, balance, last_transaction_date) VALUES (%s, %s, %s, %s, %s)",
                           (full_name, account_number, pin, 0.0, date.today()))
            conn.commit()

            print(f"User Registered Successfully! Your account number is: {account_number}")
    finally:
        conn.close()

def acc_number_generator():
    return str(random.randint(1000000000, 9999999999))
