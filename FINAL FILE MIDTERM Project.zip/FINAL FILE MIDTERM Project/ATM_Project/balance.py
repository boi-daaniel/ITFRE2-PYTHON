from db_connection import create_connection

# Check Balance Function
def check_balance(account_number):
    conn = create_connection()
    if conn is None:
        print("Unable to connect to the database.")
        return

    try:
        with conn.cursor() as cursor:
            cursor.execute("SELECT balance FROM users WHERE account_number=%s", (account_number,))
            balance = cursor.fetchone()
            if balance:
                print("--Current Balance--")
                print(f"\t${balance[0]: .2f}")
            else:
                print("Account not found.")
    finally:
        conn.close()
